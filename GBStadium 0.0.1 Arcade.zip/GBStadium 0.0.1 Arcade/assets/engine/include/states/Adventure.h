#ifndef STATE_ADVENTURE_H
#define STATE_ADVENTURE_H

#include <gb/gb.h>

void Start_Adventure();
void Update_Adventure();

#endif
