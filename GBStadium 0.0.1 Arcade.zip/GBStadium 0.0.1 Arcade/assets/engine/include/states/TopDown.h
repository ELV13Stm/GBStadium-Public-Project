#ifndef STATE_TOP_DOWN_H
#define STATE_TOP_DOWN_H

#include <gb/gb.h>

void Start_TopDown();
void Update_TopDown();

#endif
